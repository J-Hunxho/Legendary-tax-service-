
import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Stats from './components/Stats';
import Services from './components/Services';
import SuccessStories from './components/SuccessStories';
import Pricing from './components/Pricing';
import IntakeForm from './components/IntakeForm';
import Footer from './components/Footer';
import ParticleBackground from './components/ParticleBackground';
import TubeManChat from './components/TubeManChat';
import IrsAgentGuide from './components/IrsAgentGuide';

const App: React.FC = () => {
  const [isIntakeOpen, setIsIntakeOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#00008B] selection:bg-[#FFD700] selection:text-[#00008B]">
      <ParticleBackground />
      
      <Header onContactClick={() => setIsIntakeOpen(true)} />
      
      <main className="relative z-10">
        <Hero onCtaClick={() => setIsIntakeOpen(true)} />
        <Stats />
        <Services />
        
        <section id="academy" className="py-32 px-6 md:px-12 max-w-7xl mx-auto">
          <div className="bg-[#FFD700] rounded-[3rem] p-12 md:p-24 overflow-hidden relative group">
             <div className="absolute top-0 right-0 w-1/3 h-full bg-[#EF4444] skew-x-12 transform translate-x-1/2 opacity-10"></div>
             <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                   <span className="bg-[#00008B] text-white px-6 py-2 rounded-full text-xs font-black tracking-widest uppercase mb-8 inline-block">Tax Preparation Class</span>
                   <h2 className="text-4xl md:text-7xl font-black text-[#00008B] leading-none mb-8 uppercase tracking-tighter">
                      Turn Knowledge <br />
                      <span className="text-[#EF4444]">Into Income</span>
                   </h2>
                   <div className="space-y-4 mb-10">
                      {[
                        "Learn step-by-step how to start a tax business",
                        "Make up to $50K in your first year",
                        "No experience needed - work from home",
                        "Taught by professionals with 20+ years experience"
                      ].map((item, idx) => (
                        <div key={idx} className="flex items-center gap-4 text-[#00008B]/80 font-bold">
                           <div className="w-6 h-6 bg-white rounded-md flex items-center justify-center shadow-md">
                              <svg className="w-4 h-4 text-[#EF4444]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M5 13l4 4L19 7" strokeWidth={3} /></svg>
                           </div>
                           {item}
                        </div>
                      ))}
                   </div>
                   <button onClick={() => setIsIntakeOpen(true)} className="bg-[#00008B] text-white px-12 py-6 rounded-2xl font-black text-xl hover:bg-black transition-colors uppercase shadow-2xl glimmer-btn">
                      Enroll Now
                   </button>
                </div>
                <div className="hidden lg:flex justify-center">
                   <div className="bg-white p-6 rounded-[2rem] shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500 max-w-sm">
                      <div className="bg-[#00008B]/5 h-64 rounded-xl mb-6 flex items-center justify-center text-4xl font-black text-[#00008B]/20">
                         [QR CODE]
                      </div>
                      <div className="text-center">
                         <div className="text-[#00008B] font-black text-2xl uppercase italic">Sign Up By Sept 20</div>
                         <div className="text-[#EF4444] font-bold">Classes Start Sept 22</div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </section>

        <IrsAgentGuide />
        <SuccessStories />
        <Pricing />
      </main>

      <Footer />
      <TubeManChat />
      
      {isIntakeOpen && (
        <IntakeForm onClose={() => setIsIntakeOpen(false)} />
      )}
    </div>
  );
};

export default App;