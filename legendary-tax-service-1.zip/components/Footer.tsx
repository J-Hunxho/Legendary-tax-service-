
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#00008B] py-24 px-6 border-t border-white/10 relative z-10">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
        <div className="col-span-1 md:col-span-2">
          <div className="flex flex-col mb-8">
             <div className="font-sans text-4xl font-black text-[#FACC15] tracking-tight leading-none">LEGENDARY</div>
             <div className="flex items-center gap-2 mt-1">
                <div className="flex flex-col gap-1">
                   <div className="h-1 w-16 bg-[#EF4444]"></div>
                   <div className="h-1 w-16 bg-[#EF4444]"></div>
                </div>
                <div className="text-2xl font-bold text-[#3B82F6] tracking-tighter uppercase leading-none">TAX SERVICE</div>
             </div>
          </div>
          <p className="text-gray-300 max-w-sm leading-relaxed mb-10 font-bold uppercase text-sm italic">
            Providing the Gold Standard of tax preparation to the community. Bigger Refunds. Legendary Service.
          </p>
          <div className="space-y-4">
            <div className="flex items-center gap-4 text-white">
               <div className="w-10 h-10 bg-[#EF4444] rounded-full flex items-center justify-center shadow-lg">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6.62 10.79a15.15 15.15 0 006.59 6.59l2.2-2.2a1 1 0 011.11-.27 11.72 11.72 0 003.69.59 1 1 0 011 1V20a1 1 0 01-1 1A15 15 0 013 6a1 1 0 011-1h3.5a1 1 0 011 1 11.72 11.72 0 00.59 3.69 1 1 0 01-.27 1.11l-2.2 2.2z"/></svg>
               </div>
               <span className="text-2xl font-black">(256) 441-5319</span>
            </div>
            <div className="flex items-center gap-4 text-white/70">
               <div className="w-10 h-10 bg-[#3B82F6] rounded-full flex items-center justify-center shadow-lg">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg>
               </div>
               <span className="font-bold tracking-tight">Info@legendarytaxservice.com</span>
            </div>
            <div className="flex items-center gap-4 text-white/70">
               <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg text-[#00008B]">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 010-5 2.5 2.5 0 010 5z"/></svg>
               </div>
               <span className="font-bold">1135 W Meighan Blvd Gadsden, Al 35901</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-white text-[10px] font-black tracking-[0.4em] uppercase mb-8 border-b border-[#FACC15]/20 pb-2 inline-block">Service</h4>
          <ul className="space-y-5 text-sm text-gray-400 font-bold uppercase italic">
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Refund Advance</a></li>
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Virtual Filing</a></li>
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Audit Defense</a></li>
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Tax Academy</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white text-[10px] font-black tracking-[0.4em] uppercase mb-8 border-b border-[#FACC15]/20 pb-2 inline-block">Social</h4>
          <ul className="space-y-5 text-sm text-gray-400 font-bold uppercase italic">
            <li><a href="https://facebook.com" className="hover:text-[#FACC15] transition-colors">Facebook Page</a></li>
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Instagram</a></li>
            <li><a href="#" className="hover:text-[#FACC15] transition-colors">Twitter (X)</a></li>
            <li><a href="https://legendarytaxservice.org" className="hover:text-[#FACC15] transition-colors">Official Website</a></li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-[10px] text-gray-500 tracking-[0.4em] uppercase font-black">
          © {new Date().getFullYear()} Legendary Tax Service | All Rights Reserved
        </div>
        <div className="text-[10px] text-[#FACC15] tracking-[0.4em] uppercase font-black flex gap-12">
          <span>Trusted Since 2008</span>
          <span className="text-[#EF4444]">Become Legendary</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
