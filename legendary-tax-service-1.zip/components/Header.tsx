import React, { useState, useEffect } from 'react';

interface HeaderProps {
  onContactClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onContactClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-[60] transition-all duration-500 px-6 md:px-12 py-6 ${
      isScrolled ? 'bg-[#00008B]/95 backdrop-blur-md border-b border-white/10 py-4 shadow-xl' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center gap-6 group cursor-pointer" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <div className="flex flex-col">
             <div className="font-sans text-3xl font-black text-[#FFD700] tracking-tight leading-none glimmer-text">LEGENDARY</div>
             <div className="flex items-center gap-2 mt-1">
                <div className="flex flex-col gap-1">
                   <div className="h-1 w-12 bg-[#EF4444]"></div>
                   <div className="h-1 w-12 bg-[#EF4444]"></div>
                </div>
                <div className="text-xl font-bold text-white tracking-tighter uppercase leading-none">TAX SERVICE</div>
             </div>
          </div>
          <div className="bg-white p-1 rounded-sm shadow-lg transform group-hover:scale-110 transition-transform hidden sm:block">
             <svg className="w-10 h-10" viewBox="0 0 100 100">
                <path d="M50 5 L90 25 C90 25 90 65 50 95 C10 65 10 25 10 25 L50 5Z" fill="none" stroke="#00008B" strokeWidth="4" />
                <rect x="30" y="65" width="8" height="12" fill="#FFD700" />
                <rect x="42" y="55" width="8" height="22" fill="#00008B" />
                <rect x="54" y="45" width="8" height="32" fill="#EF4444" opacity="0.8" />
                <path d="M30 70 L75 35 M75 35 L62 35 M75 35 L75 48" stroke="#EF4444" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
             </svg>
          </div>
        </div>

        <nav className="hidden lg:flex items-center gap-10 text-[11px] font-black tracking-[0.2em] text-white/70">
          <a href="#" className="hover:text-[#FFD700] transition-all">HOME</a>
          <a href="#services" className="hover:text-[#FFD700] transition-all">SERVICES</a>
          <a href="#irs-guide" className="hover:text-[#FFD700] transition-all">IRS GUIDE</a>
          <a href="#academy" className="hover:text-[#FFD700] transition-all text-[#FFD700]">TAX ACADEMY</a>
        </nav>

        <button 
          onClick={onContactClick}
          className="relative overflow-hidden bg-[#FFD700] text-[#00008B] px-8 py-3 rounded-md text-[11px] font-black tracking-widest transition-all duration-300 hover:bg-white hover:shadow-[0_0_30px_rgba(255,215,0,0.4)] uppercase glimmer-btn"
        >
          Inbox Me Now!
        </button>
      </div>
    </header>
  );
};

export default Header;