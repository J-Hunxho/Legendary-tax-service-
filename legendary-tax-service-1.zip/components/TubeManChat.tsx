import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Message } from '../types';

const TubeManChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Hello! I'm your Legendary Tax assistant. Looking for your 2024 refund status or have a tax question?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [...messages, userMessage].map(m => ({
            role: m.role,
            parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction: "You are the Legendary Tax Service Concierge. Your tone is friendly, professional, and neighborly. You help everyday consumers with tax questions. If they ask about current dates, deadlines, or 2024/2025 tax laws, use your search tool. Always remind them that while you are helpful, for complex filings they should book a session with our human experts. Keep responses concise and avoid heavy jargon. Colors: Blue, Gold, Red, White.",
          temperature: 0.7,
          tools: [{ googleSearch: {} }]
        }
      });

      const aiText = response.text || "I'm having a bit of trouble connecting to the database. Could you try rephrasing that?";
      setMessages(prev => [...prev, { role: 'model', text: aiText }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "Service temporarily unavailable. Please call us for immediate help!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-10 right-10 z-[100] flex flex-col items-end">
      {isOpen && (
        <div className="mb-6 w-[350px] md:w-[420px] h-[600px] bg-[#020617] border border-[#FFD700]/30 rounded-[2.5rem] shadow-[0_30px_100px_rgba(0,0,0,0.8)] flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
          <div className="p-6 border-b border-[#FFD700]/10 bg-[#00008B] flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="w-3 h-3 bg-[#EF4444] rounded-full animate-pulse shadow-[0_0_10px_#EF4444]"></div>
              <div className="flex flex-col">
                <span className="text-[10px] font-black tracking-[0.4em] uppercase text-[#FFD700]">Tax Concierge</span>
                <span className="text-[9px] text-white/50 font-bold uppercase tracking-widest">Powered by Gemini AI</span>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/50 hover:text-[#EF4444] transition-colors p-2 hover:bg-white/5 rounded-full">
               <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6M6 6l12 12" strokeWidth={2.5} /></svg>
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-5 rounded-3xl text-sm leading-relaxed ${
                  m.role === 'user' 
                    ? 'bg-[#FFD700] text-[#00008B] font-semibold rounded-br-none shadow-lg' 
                    : 'bg-[#00008B] text-gray-200 rounded-bl-none border border-white/5'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#00008B] p-5 rounded-3xl flex gap-2">
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 bg-[#FFD700] rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-white/5 bg-[#00008B]/20">
            <div className="flex gap-3">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about 2024 filing..."
                className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-sm focus:outline-none focus:border-[#FFD700] transition-all text-white placeholder-white/20"
              />
              <button 
                onClick={handleSend}
                className="bg-[#FFD700] p-4 rounded-2xl hover:bg-white transition-all active:scale-95 shadow-lg group"
              >
                <svg className="w-6 h-6 text-[#00008B]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path d="M5 12h14M12 5l7 7-7 7" strokeWidth={2.5} />
                </svg>
              </button>
            </div>
          </div>
        </div>
      )}

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="relative w-20 h-20 bg-[#EF4444] rounded-full flex items-center justify-center shadow-[0_10px_40px_rgba(0,0,0,0.6)] hover:scale-105 active:scale-95 border-2 border-[#FFD700]/20 transition-all group overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-tr from-[#FFD700]/20 to-transparent"></div>
        <svg className="w-10 h-10 text-white z-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
        </svg>
      </button>
    </div>
  );
};

export default TubeManChat;