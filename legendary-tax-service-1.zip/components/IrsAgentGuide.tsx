import React from 'react';

const steps = [
  "Select Language",
  "Press 2 for questions about Personal Income Taxes",
  "Press 1 for questions about a form already filed or a payment",
  "Press 3 for all other questions",
  "Press 2 for all other questions",
  "When asked to put in Social Security Number DONT PRESS ANYTHING",
  "Press 2 for Personal or Individual Tax Questions",
  "Press 3 for all other questions"
];

const IrsAgentGuide: React.FC = () => {
  return (
    <section id="irs-guide" className="py-32 px-6 bg-[#00008B]/20">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-[#EF4444] tracking-[0.6em] text-[10px] font-black uppercase mb-4 block">Exclusive Resource</span>
          <h2 className="text-4xl md:text-6xl font-black text-white leading-tight uppercase tracking-tighter mb-4">
            Get a Live <span className="glimmer-text uppercase italic">IRS Agent</span>
          </h2>
          <div className="inline-block bg-[#FFD700] text-[#00008B] px-10 py-4 rounded-full text-3xl font-black shadow-2xl glimmer-btn">
            1-800-829-1040
          </div>
        </div>

        <div className="bg-[#00008B] border border-[#FFD700]/10 rounded-[3rem] p-8 md:p-16 shadow-inner relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-[#EF4444]"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
            {steps.map((step, idx) => (
              <div key={idx} className="flex gap-6 items-start group">
                <div className="w-10 h-10 shrink-0 bg-[#FFD700] text-[#00008B] rounded-xl flex items-center justify-center font-black text-xl shadow-lg transform group-hover:rotate-12 transition-transform">
                  {idx + 1}
                </div>
                <div className="text-white text-lg font-bold uppercase tracking-tight leading-tight pt-1">
                  {step}
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-16 text-center border-t border-white/10 pt-10">
            <p className="text-[#FFD700] text-2xl font-black italic animate-pulse uppercase tracking-widest glimmer-text">
              After completing steps 1-8, wait patiently for a representative
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default IrsAgentGuide;