import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

interface HeroProps {
  onCtaClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onCtaClick }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(contentRef.current, {
        y: 60,
        opacity: 0,
        duration: 1.2,
        ease: "power4.out"
      });
    }, containerRef);
    return () => ctx.revert();
  }, []);

  return (
    <section ref={containerRef} className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden bg-[#00008B]">
      {/* Background Money Elements */}
      <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 pointer-events-none select-none">
        <img src="https://images.unsplash.com/photo-1580519542036-c47de6196ba5?auto=format&fit=crop&q=80&w=1000" className="w-full h-full object-cover grayscale brightness-200" alt="Money" />
      </div>

      <div className="max-w-7xl mx-auto px-6 w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        <div ref={contentRef} className="lg:col-span-8 text-center lg:text-left">
          <div className="inline-block px-6 py-2 bg-[#EF4444] text-white text-sm font-black tracking-[0.2em] uppercase rounded-sm mb-6 shadow-xl">
             Bigger Refunds! Legendary Service!
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black text-white leading-none mb-8 uppercase tracking-tighter">
            Refund Advance <br />
            <span className="glimmer-text italic">Up to $7,000</span>
          </h1>

          <div className="bg-[#020617]/60 backdrop-blur-md border-l-4 border-[#FFD700] p-8 rounded-r-2xl max-w-2xl mb-10 shadow-2xl">
             <p className="text-2xl md:text-3xl font-bold text-white mb-2">Pre-file today and receive your advance on Jan 2, 2025!</p>
             <p className="text-[#FFD700] text-lg uppercase tracking-widest font-black italic">Virtual Filing From Home Available</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center lg:justify-start items-center mb-12">
            <button 
              onClick={onCtaClick}
              className="w-full sm:w-auto bg-[#FFD700] text-[#00008B] px-12 py-6 rounded-md font-black tracking-widest text-lg hover:scale-105 transition-transform shadow-2xl uppercase glimmer-btn"
            >
              Start My $7,000 Advance
            </button>
            <div className="text-left group cursor-default">
              <div className="text-white font-black text-xl leading-tight group-hover:text-[#FFD700] transition-colors">1135 W Meighan Blvd</div>
              <div className="text-[#FFD700] font-bold text-lg glimmer-text">Gadsden, Al 35901</div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 hidden lg:block">
           <div className="relative group">
              <div className="absolute -inset-4 bg-[#FFD700] rounded-3xl blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
              <div className="relative bg-white/5 border border-white/10 p-4 rounded-3xl overflow-hidden shadow-2xl backdrop-blur-sm">
                 <img 
                    src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&q=80&w=600" 
                    alt="Tax Service" 
                    className="rounded-2xl w-full h-auto grayscale group-hover:grayscale-0 transition-all duration-700"
                 />
                 <div className="mt-6 text-center">
                    <div className="text-[#FFD700] text-4xl font-black italic mb-2 glimmer-text uppercase">FILE TODAY!</div>
                    <div className="text-white text-2xl font-black uppercase">GET MONEY TODAY!</div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;