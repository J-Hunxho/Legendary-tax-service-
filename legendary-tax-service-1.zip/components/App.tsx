
import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Stats from './components/Stats';
import SuccessStories from './components/SuccessStories';
import Pricing from './components/Pricing';
import IntakeForm from './components/IntakeForm';
import Footer from './components/Footer';
import ParticleBackground from './components/ParticleBackground';

const App: React.FC = () => {
  const [isIntakeOpen, setIsIntakeOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#020617] selection:bg-[#D4AF37] selection:text-[#020617]">
      <ParticleBackground />
      
      <Header onContactClick={() => setIsIntakeOpen(true)} />
      
      <main className="relative z-10">
        <Hero onCtaClick={() => setIsIntakeOpen(true)} />
        <Stats />
        
        <section id="services" className="py-32 px-6 md:px-12 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="w-16 h-1.5 bg-[#C41E3A] mb-10 shadow-[0_0_15px_#C41E3A]"></div>
              <h2 className="text-4xl md:text-6xl font-serif mb-8 text-white leading-tight">
                Tax Help For <br />
                <span className="glimmer-text italic">Real People</span>
              </h2>
              <p className="text-gray-400 text-lg mb-10 leading-relaxed font-light">
                Whether you're a first-time filer, a growing family, or a side-hustler, we bring a premium level of care to your personal taxes. No confusing jargon—just results.
              </p>
              <div className="space-y-6">
                {[
                  "Maximum Refund Guarantee",
                  "Family Credit Optimization",
                  "Small Business & Freelance Support",
                  "Professional Audit Protection"
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-5 group">
                    <div className="w-8 h-8 rounded-xl border border-[#D4AF37]/30 flex items-center justify-center group-hover:bg-[#C41E3A] group-hover:border-[#C41E3A] transition-all duration-300">
                      <svg className="w-4 h-4 text-[#D4AF37] group-hover:text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-gray-200 font-medium tracking-wide group-hover:text-[#D4AF37] transition-colors">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative aspect-square rounded-[2.5rem] overflow-hidden border border-[#D4AF37]/10 shadow-2xl group">
              <img 
                src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=1200" 
                alt="Personalized Service" 
                className="object-cover w-full h-full opacity-50 grayscale group-hover:grayscale-0 transition-all duration-1000"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-transparent to-transparent opacity-90"></div>
              <div className="absolute bottom-10 left-10 right-10">
                <div className="text-[10px] font-black tracking-[0.5em] text-[#C41E3A] uppercase mb-3">Our Promise</div>
                <div className="text-2xl font-serif text-white leading-tight">Expert service that's actually easy to talk to.</div>
              </div>
            </div>
          </div>
        </section>

        <SuccessStories />
        <Pricing />
      </main>

      <Footer />
      {isIntakeOpen && <IntakeForm onClose={() => setIsIntakeOpen(false)} />}
    </div>
  );
};

export default App;
