
import React from 'react';

const Stats: React.FC = () => {
  const stats = [
    { label: 'TOTAL REFUNDS', value: '$12M+' },
    { label: 'CLIENT SATISFACTION', value: '100%' },
    { label: 'YEARS IN SERVICE', value: '15+' },
    { label: 'FAMILIES HELPED', value: '5,000+' },
  ];

  return (
    <section className="bg-[#020617] py-20 border-y border-[#FFD700]/10 backdrop-blur-md relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-12 relative z-10">
        {stats.map((stat, idx) => (
          <div key={idx} className="text-center group cursor-default">
            <div className="text-4xl md:text-5xl font-serif text-[#FFD700] mb-3 tracking-tighter glimmer-text transition-all duration-300 transform group-hover:scale-110">
              {stat.value}
            </div>
            <div className="text-[10px] md:text-xs font-black tracking-[0.4em] text-[#EF4444] opacity-80 uppercase group-hover:opacity-100 transition-opacity">
              {stat.label}
            </div>
          </div>
        ))}
      </div>
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#FFD700]/5 to-transparent"></div>
    </section>
  );
};

export default Stats;
