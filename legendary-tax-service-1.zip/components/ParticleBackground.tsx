
import React, { useEffect, useRef } from 'react';

const ParticleBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let particles: DollarParticle[] = [];
    const particleCount = 80;
    let w: number, h: number;

    const mouse = {
      x: -1000,
      y: -1000,
      radius: 180
    };

    class DollarParticle {
      x: number;
      y: number;
      symbol: string = '$';
      fontSize: number;
      baseX: number;
      baseY: number;
      density: number;
      opacity: number;
      rotation: number;
      rotationSpeed: number;

      constructor() {
        this.x = Math.random() * w;
        this.y = Math.random() * h;
        this.fontSize = Math.random() * 18 + 12;
        this.baseX = this.x;
        this.baseY = this.y;
        this.density = (Math.random() * 30) + 1;
        this.opacity = Math.random() * 0.3 + 0.1;
        this.rotation = Math.random() * Math.PI * 2;
        this.rotationSpeed = (Math.random() - 0.5) * 0.005;
      }

      draw() {
        if (!ctx) return;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        // Bright glistening gold for currency
        ctx.fillStyle = `rgba(255, 215, 0, ${this.opacity})`;
        ctx.font = `bold ${this.fontSize}px 'Fraunces', serif`;
        ctx.shadowBlur = 8;
        ctx.shadowColor = 'rgba(255, 215, 0, 0.4)';
        ctx.fillText(this.symbol, 0, 0);
        ctx.restore();
      }

      update() {
        this.rotation += this.rotationSpeed;
        
        let dx = mouse.x - this.x;
        let dy = mouse.y - this.y;
        let distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < mouse.radius) {
          // Force is inversely proportional to distance
          let force = (mouse.radius - distance) / mouse.radius;
          let forceDirectionX = dx / distance;
          let forceDirectionY = dy / distance;
          
          // Move AWAY from mouse (opposing movement)
          let directionX = forceDirectionX * force * this.density;
          let directionY = forceDirectionY * force * this.density;
          
          this.x -= directionX;
          this.y -= directionY;
        } else {
          // Gradually return to base position when mouse is away
          if (this.x !== this.baseX) {
            let dxReturn = this.x - this.baseX;
            this.x -= dxReturn / 30;
          }
          if (this.y !== this.baseY) {
            let dyReturn = this.y - this.baseY;
            this.y -= dyReturn / 30;
          }
        }
      }
    }

    const init = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      particles = [];
      for (let i = 0; i < particleCount; i++) {
        particles.push(new DollarParticle());
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < particles.length; i++) {
        particles[i].draw();
        particles[i].update();
      }
      requestAnimationFrame(animate);
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        mouse.x = e.touches[0].clientX;
        mouse.y = e.touches[0].clientY;
      }
    };

    window.addEventListener('resize', init);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove);

    init();
    animate();

    return () => {
      window.removeEventListener('resize', init);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 bg-[#020617]"
      style={{ opacity: 0.8 }}
    />
  );
};

export default ParticleBackground;
