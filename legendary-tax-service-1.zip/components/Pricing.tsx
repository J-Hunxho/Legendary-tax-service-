
import React from 'react';
import { PricingTier } from '../types';

const tiers: PricingTier[] = [
  {
    name: 'Individual',
    price: 'Custom Quote',
    description: 'Perfect for W2 earners and straightforward filers.',
    features: [
      'Federal & State Filing',
      'Max Deduction Check',
      'Digital Document Secure Vault',
      'Phone Support'
    ]
  },
  {
    name: 'Family Plus',
    price: 'Custom Quote',
    description: 'Our most popular tier for households with kids & property.',
    features: [
      'Child Tax Credit Optimization',
      'Education & Medical Deductions',
      'Investment & Crypto Support',
      'Full Audit Defense Included',
      'Year-Round Q&A'
    ],
    isPopular: true
  },
  {
    name: 'Pro / Small Biz',
    price: 'Custom Quote',
    description: 'Built for freelancers, contractors, and side-hustlers.',
    features: [
      'Schedule C & LLC Filing',
      'Expense Strategy Review',
      'Home Office Deduction',
      'Quarterly P&L Summaries',
      'VIP Support Line'
    ]
  }
];

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-32 px-6 md:px-12 bg-gradient-to-t from-[#020617] to-[#07122a] relative">
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-24">
          <span className="text-[10px] tracking-[0.6em] text-[#EF4444] uppercase font-black mb-4 block">Fair & Transparent</span>
          <h2 className="text-4xl md:text-7xl font-serif mb-8 text-white leading-tight font-black">Premium <span className="glimmer-text uppercase">Value.</span></h2>
          <p className="text-gray-400 max-w-2xl mx-auto text-lg font-light leading-relaxed">We don't believe in one-size-fits-all fees. Contact us today for actual pricing tailored specifically to your financial situation.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {tiers.map((tier, idx) => (
            <div 
              key={idx} 
              className={`relative p-12 rounded-[2.5rem] border transition-all duration-700 group flex flex-col ${
                tier.isPopular 
                  ? 'bg-white/[0.03] border-[#FFD700] shadow-[0_40px_80px_rgba(255,215,0,0.15)] scale-105 z-10' 
                  : 'bg-transparent border-white/5 hover:border-[#FFD700]/30'
              }`}
            >
              {tier.isPopular && (
                <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-[#EF4444] text-white text-[10px] font-black tracking-[0.3em] px-8 py-2 rounded-full uppercase shadow-xl">
                  Best Value
                </div>
              )}
              
              <div className="mb-10 text-center">
                <h3 className="text-2xl font-serif mb-4 text-white group-hover:glimmer-text transition-all uppercase tracking-tight">{tier.name}</h3>
                <div className="text-3xl font-black mb-4 text-[#FFD700] tracking-tight uppercase italic glimmer-text">Contact Us</div>
                <p className="text-sm text-gray-500 font-bold uppercase tracking-widest leading-relaxed">For Actual Pricing</p>
                <p className="text-xs text-gray-400 mt-4 font-light italic">{tier.description}</p>
              </div>

              <div className="flex-1">
                <ul className="space-y-5 mb-12">
                  {tier.features.map((feature, fIdx) => (
                    <li key={fIdx} className="flex gap-4 text-sm text-gray-300 font-light items-start">
                      <svg className="w-5 h-5 text-[#EF4444] shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <button className={`glimmer-btn w-full py-5 rounded-2xl font-black tracking-widest text-[10px] transition-all duration-300 relative overflow-hidden group/btn hover:scale-105 active:scale-95 shadow-xl ${
                tier.isPopular 
                  ? 'bg-[#FFD700] text-[#00008B]' 
                  : 'bg-white/5 text-white hover:bg-white/10'
              }`}>
                <span className="relative z-10 uppercase font-black">GET A CUSTOM QUOTE</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;
