
export const MockApiService = {
  submitIntake: async (data: any) => {
    // Simulate real network delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Simulate server-side validation
    if (!data.email.includes('@')) {
      throw new Error("Invalid protocol address provided.");
    }

    console.log("Backend received intake request:", data);
    return { status: 'success', ref: `GOLD-${Math.floor(Math.random() * 99999)}` };
  },

  trackAudit: async (id: string) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { status: 'secure', protectionLevel: '100%' };
  }
};
