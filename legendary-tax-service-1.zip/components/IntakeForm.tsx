import React, { useState } from 'react';
import { MockApiService } from './MockApiService';

interface IntakeFormProps {
  onClose: () => void;
}

const IntakeForm: React.FC<IntakeFormProps> = ({ onClose }) => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    goal: '',
    revenue: '',
    name: '',
    email: ''
  });

  const nextStep = () => setStep(s => s + 1);
  const prevStep = () => setStep(s => s - 1);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');
    
    try {
      await MockApiService.submitIntake(formData);
      setStep(5);
    } catch (err: any) {
      setError(err.message || "A system error occurred. Please retry.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-6">
      <div 
        className="absolute inset-0 bg-[#020617]/95 backdrop-blur-xl"
        onClick={onClose}
      ></div>
      
      <div className="relative w-full max-w-xl bg-[#00008B] border border-[#FFD700]/20 p-12 rounded-[2.5rem] shadow-2xl overflow-hidden">
        <div className="absolute top-0 left-0 h-1 bg-[#EF4444] transition-all duration-700" style={{ width: `${(step / 4) * 100}%` }}></div>
        
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 text-white/50 hover:text-[#FFD700] transition-colors"
        >
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {step === 1 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-3xl font-serif mb-8 text-white">How can we help you today?</h3>
            <div className="space-y-4">
              {['Individual Tax Filing', 'Family / Child Credits', 'Small Biz / Side Hustle'].map(opt => (
                <button 
                  key={opt}
                  onClick={() => { setFormData({...formData, goal: opt}); nextStep(); }}
                  className="w-full text-left p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-[#FFD700] hover:bg-[#FFD700]/10 transition-all text-lg text-gray-200"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-3xl font-serif mb-8 text-white">Annual income range?</h3>
            <div className="space-y-4">
              {['Under $60k', '$60k - $120k', '$120k - $250k', '$250k+'].map(opt => (
                <button 
                  key={opt}
                  onClick={() => { setFormData({...formData, revenue: opt}); nextStep(); }}
                  className="w-full text-left p-6 rounded-2xl bg-white/5 border border-white/10 hover:border-[#FFD700] hover:bg-[#FFD700]/10 transition-all text-lg text-gray-200"
                >
                  {opt}
                </button>
              ))}
            </div>
            <button onClick={prevStep} className="mt-8 text-white/50 hover:text-[#FFD700] text-[10px] font-black tracking-widest uppercase">Go Back</button>
          </div>
        )}

        {step === 3 && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h3 className="text-3xl font-serif mb-8 text-white">Your Contact Details</h3>
            <div className="space-y-6">
              <div>
                <label className="block text-[10px] font-black tracking-[0.3em] text-[#FFD700] uppercase mb-3">Full Name</label>
                <input 
                  type="text" 
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:border-[#FFD700] focus:outline-none transition-all text-white placeholder-white/20"
                  placeholder="Jane Smith"
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-[10px] font-black tracking-[0.3em] text-[#FFD700] uppercase mb-3">Email Address</label>
                <input 
                  type="email" 
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 focus:border-[#FFD700] focus:outline-none transition-all text-white placeholder-white/20"
                  placeholder="jane@example.com"
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                />
              </div>
              {error && <p className="text-[#EF4444] text-xs font-bold">{error}</p>}
              <button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="glimmer-btn w-full bg-[#FFD700] text-[#00008B] py-5 rounded-2xl font-black tracking-[0.2em] transition-all flex items-center justify-center gap-4 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-[#00008B] border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  "SECURE MY FILING"
                )}
              </button>
            </div>
            <button onClick={prevStep} className="mt-8 text-white/50 hover:text-[#FFD700] text-[10px] font-black tracking-widest uppercase">Go Back</button>
          </div>
        )}

        {step === 5 && (
          <div className="text-center animate-in zoom-in duration-500">
            <div className="w-24 h-24 bg-[#FFD700]/20 text-[#FFD700] rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_30px_rgba(255,215,0,0.2)]">
              <svg className="w-12 h-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-3xl font-serif mb-4 text-white">System Verified.</h3>
            <p className="text-gray-400 mb-10 font-light leading-relaxed">Your application has been received. A local tax expert will contact you within 2 business hours to begin your refund process.</p>
            <button 
              onClick={onClose}
              className="bg-white/10 text-white px-10 py-4 rounded-full text-[10px] font-black tracking-widest uppercase hover:bg-white/20 transition-all"
            >
              FINISH
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default IntakeForm;