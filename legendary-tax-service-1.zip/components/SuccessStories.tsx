
import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { SuccessStory } from '../types';

gsap.registerPlugin(ScrollTrigger);

const stories: SuccessStory[] = [
  {
    client: "The Miller Family",
    challenge: "Overwhelmed with multiple jobs and new property tax credits.",
    solution: "Personalized credit review and historic deduction recovery.",
    metric: "$4,200",
    metricLabel: "Extra Refund"
  },
  {
    client: "Downtown Coffee Co.",
    challenge: "Local cafe scaling to their second location with complex payroll.",
    solution: "S-Corp transition and automated expense tracking setup.",
    metric: "20%",
    metricLabel: "Tax Savings"
  },
  {
    client: "Freelance Designer",
    challenge: "Confused about home office rules and self-employment taxes.",
    solution: "Simplified home-office deduction strategy and quarterly planning.",
    metric: "$2,500",
    metricLabel: "Annual Savings"
  }
];

const SuccessStories: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = gsap.utils.toArray('.success-card');
      
      cards.forEach((card: any, index: number) => {
        gsap.from(card, {
          scrollTrigger: {
            trigger: card,
            start: "top 92%",
            toggleActions: "play none none none",
          },
          y: 40,
          opacity: 0,
          duration: 1,
          ease: "power3.out",
          delay: index * 0.1,
        });
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section id="success" className="py-32 px-6 md:px-12 bg-[#020617] relative overflow-hidden" ref={sectionRef}>
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="mb-24 text-center">
          <span className="text-[#EF4444] tracking-[0.6em] text-[10px] font-black uppercase mb-6 block">Real Results</span>
          <h2 className="text-4xl md:text-7xl font-serif text-white max-w-4xl mx-auto leading-[1.1] tracking-tight">
            Happy Clients. <br /> 
            <span className="glimmer-text">Bigger Refunds.</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {stories.map((story, idx) => (
            <div 
              key={idx}
              className="success-card bg-white/[0.02] border border-white/5 p-12 rounded-[2.5rem] hover:border-[#FFD700]/30 transition-all duration-700 group relative overflow-hidden"
            >
              <div className="flex justify-between items-start mb-12">
                <div className="p-3.5 rounded-2xl bg-[#FFD700]/10 text-[#FFD700]">
                  <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                     <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15l-5-5 1.41-1.41L11 14.17l7.59-7.59L20 8l-9 9z" />
                  </svg>
                </div>
                <div className="text-right">
                  <div className="text-4xl font-serif text-[#FFD700] tracking-tighter font-black">{story.metric}</div>
                  <div className="text-[9px] tracking-[0.3em] text-[#EF4444] uppercase font-black mt-1">{story.metricLabel}</div>
                </div>
              </div>

              <h3 className="text-2xl font-serif text-white mb-6 font-bold group-hover:text-[#FFD700] transition-colors">{story.client}</h3>
              <p className="text-gray-400 text-sm leading-relaxed font-light mb-4">{story.challenge}</p>
              <div className="pt-6 border-t border-white/5">
                <p className="text-gray-200 text-sm italic font-light">"{story.solution}"</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;
