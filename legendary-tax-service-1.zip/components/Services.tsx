
import React from 'react';

const serviceList = [
  {
    title: "Refund Advance",
    desc: "Get your money early. Up to $7,000 advance available when you pre-file for the 2025 season.",
    icon: "M12 8c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3z M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z",
    details: ["No Credit Check", "Direct Deposit Next Day", "Shortest Approval Time"]
  },
  {
    title: "Virtual Filing",
    desc: "File from the comfort of your home. Secure, encrypted, and incredibly fast processing.",
    icon: "M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z",
    details: ["Secure Document Upload", "Expert Video Review", "Digital Signature"]
  },
  {
    title: "Tax Academy",
    desc: "Learn, Earn, Become Legendary. Join our preparation class and start your business journey.",
    icon: "M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253",
    details: ["Earn up to $50K First Year", "No Experience Needed", "Step-by-Step Training"]
  },
  {
    title: "Expert Defense",
    desc: "Full audit protection and direct communication with IRS agents to resolve any issues.",
    icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
    details: ["Direct IRS Negotiation", "Letter Response Service", "Professional Representation"]
  }
];

const Services: React.FC = () => {
  return (
    <section id="services" className="py-32 px-6 md:px-12 max-w-7xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
        <div className="max-w-2xl">
          <div className="w-16 h-1.5 bg-[#EF4444] mb-10 shadow-[0_0_15px_#EF4444]"></div>
          <h2 className="text-4xl md:text-6xl font-black text-white leading-tight uppercase tracking-tighter">
            Legendary Service. <br />
            <span className="text-[#FACC15]">Guaranteed.</span>
          </h2>
        </div>
        <p className="text-gray-400 text-lg max-w-md font-light leading-relaxed">
          From neighborhood filings to professional tax training, we provide the gold standard in financial growth.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {serviceList.map((service, idx) => (
          <div key={idx} className="group p-10 rounded-3xl bg-white/[0.02] border border-white/5 hover:border-[#FACC15]/30 transition-all duration-500 flex flex-col h-full hover:bg-white/[0.04]">
            <div className="w-16 h-16 bg-[#00008B] border border-[#FACC15]/20 rounded-2xl flex items-center justify-center text-[#FACC15] mb-8 group-hover:bg-[#FACC15] group-hover:text-[#00008B] transition-all transform group-hover:-translate-y-2">
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={service.icon} />
              </svg>
            </div>
            <h3 className="text-2xl font-black text-white mb-4 group-hover:text-[#FACC15] transition-colors uppercase tracking-tight">{service.title}</h3>
            <p className="text-gray-400 text-sm font-light leading-relaxed mb-8 flex-1">
              {service.desc}
            </p>
            <ul className="space-y-3 pt-6 border-t border-white/5">
              {service.details.map((detail, dIdx) => (
                <li key={dIdx} className="text-[10px] tracking-widest text-white/50 flex items-center gap-2 uppercase font-black">
                  <div className="w-1.5 h-1.5 bg-[#EF4444] rounded-full"></div>
                  {detail}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Services;
